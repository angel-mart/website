document.getElementById('startBtn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ command: "start" });
    document.getElementById('status').innerText = "Status: Running...";
    document.getElementById('status').style.color = "green";
});

document.getElementById('stopBtn').addEventListener('click', () => {
    chrome.runtime.sendMessage({ command: "stop" });
    document.getElementById('status').innerText = "Status: Stopped.";
    document.getElementById('status').style.color = "red";
});