const SHEETDB_URL = "https://sheetdb.io/api/v1/g048qvsq925es";
const TARGET_CATEGORY = "Groceries";

let isRunning = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.command === "start") {
        if (!isRunning) {
            isRunning = true;
            startScraping();
        }
    } else if (request.command === "stop") {
        isRunning = false;
        console.log("Stop command received!");
    }
});

async function interruptibleSleep(ms) {
    let iterations = ms / 100;
    for (let i = 0; i < iterations; i++) {
        if (!isRunning) return false;
        await new Promise(resolve => setTimeout(resolve, 100));
    }
    return true;
}

// --- NEW FUNCTION: Converts any image format into a pure PNG ---
async function convertToTruePNG(imageUrl) {
    try {
        // Fetch the raw image data
        let response = await fetch(imageUrl);
        let blob = await response.blob();
        
        // Turn it into a bitmap image
        let imageBitmap = await createImageBitmap(blob);
        
        // Create an invisible canvas matching the image dimensions
        let canvas = new OffscreenCanvas(imageBitmap.width, imageBitmap.height);
        let ctx = canvas.getContext('2d');
        
        // Draw the image onto the canvas and export as pure PNG blob
        ctx.drawImage(imageBitmap, 0, 0);
        let pngBlob = await canvas.convertToBlob({ type: 'image/png' });
        
        // Convert the Blob into a format Chrome can download directly
        return new Promise((resolve, reject) => {
            let reader = new FileReader();
            reader.onloadend = () => resolve(reader.result);
            reader.onerror = reject;
            reader.readAsDataURL(pngBlob);
        });
    } catch (e) {
        console.error("Error converting image:", e);
        return null;
    }
}

async function startScraping() {
    console.log("Starting automation...");
    
    let response = await fetch(SHEETDB_URL);
    let data = await response.json();
    let itemsToProcess = data.filter(item => item.Category === TARGET_CATEGORY);
    
    if (itemsToProcess.length === 0) {
        console.log("No Groceries found in SheetDB data.");
        isRunning = false;
        return;
    }

    for (let item of itemsToProcess) {
        if (!isRunning) {
            console.log("Automation halted by user.");
            break; 
        }

        let productName = item.Product_Name;
        let safeFilename = productName.replace(/[\\/*?:"<>|]/g, "") + ".png";
        
        console.log(`Searching for: ${productName}`);
        
        let searchUrl = `https://www.walmart.com/search?q=${encodeURIComponent(productName)}`;
        let newTab = await chrome.tabs.create({ url: searchUrl, active: false });
        
        let completedSleep = await interruptibleSleep(5000);
        
        if (!completedSleep) {
            chrome.tabs.remove(newTab.id);
            break;
        }
        
        try {
            let results = await chrome.scripting.executeScript({
                target: { tabId: newTab.id },
                func: () => {
                    let img = document.querySelector('img[data-testid="productTileImage"]');
                    return img ? img.src : null;
                }
            });
            
            let imageUrl = results[0].result;
            
            if (imageUrl) {
                console.log("Converting to pure PNG...");
                // Pass the URL through our new conversion engine
                let purePngData = await convertToTruePNG(imageUrl);
                
                if (purePngData) {
                    chrome.downloads.download({
                        url: purePngData, 
                        filename: `product_images/${safeFilename}`,
                        conflictAction: "overwrite"
                    });
                    console.log(`✅ Downloaded true PNG: ${safeFilename}`);
                }
            } else {
                console.log(`❌ No image found for: ${productName}`);
            }
        } catch (e) {
            console.error(`Error scraping ${productName}:`, e);
        }
        
        chrome.tabs.remove(newTab.id);
        await interruptibleSleep(3000);
    }
    
    isRunning = false;
    console.log("Automation finished or stopped.");
}